/* SAMPLE PROJECT _ 1 _ OF _ 2 */ 
/* Oscar Cueva*/

/*Set Time Zone*/
set time_zone='-4:00';
select now();

/*Preliminary Data Collection
select * to investigate your tables.*/
select * from ba710case.ba710_prod;
select * from ba710case.ba710_sales;
select * from ba710case.ba710_emails;

/*Investigate production dates and prices from the prod table*/
select * from ba710case.ba710_prod
	where product_type='scooter' 
    order by production_start_date;
    
select * from ba710case.ba710_prod
	where product_type='scooter' 
    order by base_msrp;

/***PRELIMINARY ANALYSIS***/

/*Create a new table in BA710case that is a subset of the prod table
which only contains scooters.
Result should have 7 records.*/

create table ba710case.case_scoot_names as
	select * from ba710case.ba710_prod
    where product_type='scooter';

select * from ba710case.case_scoot_names;

/*Use a join to combine the table above with the sales information*/

create table ba710case.case_scoot_sales as 
	select a.model, a.product_type, a.product_id,
    b.customer_id, b.sales_transaction_date, date(b.sales_transaction_date) as sale_date,
    b.sales_amount, b.channel, b.dealership_id
from ba710case.case_scoot_names a 
inner join ba710case.ba710_sales b
    on a.product_id=b.product_id;
    
select * from ba710case.case_scoot_sales;
    
/*Create a list partition for the case_scoot_sales table on product_id. (Hint: Alter table)  
Create one partition for each product_type.
Name each partition as the product's name.*/

alter table ba710case.case_scoot_sales
   partition by list(product_id)
   (partition lemon_2010 values in (1),
	partition lemon_lim_ed_2011 values in (2),
    partition lemon_2013 values in (3),
    partition blade_2014 values in (5),
    partition bat_2016 values in (7),
    partition bat_lim_ed_2017 values in (8),
    partition lemon_zester values in (12)
    );
    
/***PART 1: INVESTIGATE BAT SALES TRENDS***/  

/*Select Bat models from your table.*/

select *
	from ba710case.case_scoot_sales
	where model='Bat';

/*Count the number of Bat sales from your table.*/

select count(*) as count_bat_sales
	from ba710case.case_scoot_sales
	where model='Bat';

/*What is the total revenue of Bat sales?*/

select sum(sales_amount) as total_revenue
	from ba710case.case_scoot_sales
	where model='Bat';

/*When was most recent Bat sale?*/

select sale_date as most_recent_sale
	from ba710case.case_scoot_sales
	where model='Bat'
    order by sales_transaction_date desc
    limit 1;
    
/*Now create a table of daily sales.
Summarize of count of sales and sum of sales amount by date and product id 
(one record for each date & product id combination).
Include model, product_id, sale_date and a column for total sales for each day*/

CREATE TABLE ba710case.case_daily_sales AS
	select p.model, p.product_id, date(s.sales_transaction_date) as sale_date, 
		   round(sum(s.sales_amount),2) as daily_sales
	from ba710case.ba710_sales as s 
    inner join ba710case.ba710_prod as p
		on s.product_id=p.product_id
    group by date(s.sales_transaction_date),p.product_id,p.model;

select * from ba710case.case_daily_sales;


/*Now quantify the sales drop*/
/*Create a table of cumulative sales figures for just the Bat scooter from
the daily sales table you created.
Using the table created above, add a column that contains the cumulative
sales amount (one row per date).*/

CREATE TABLE ba710case.case_cumul_sales AS
select *, round((sum(daily_sales) over(order by sale_date)),2) as cumulative_sales
	from ba710case.case_daily_sales
	where model='Bat';

select * from ba710case.case_cumul_sales;

/*Compute the cumulative sales for the previous week for just the Bat scooter. 
(i.e., running total of sales for previous week.)
This is calculated as the 7 day lag of cumulative sum of sales
(i.e., each record should contain the sum of sales for the current date plus
the sales for the preceeding 6 records).

When the Word document is released with PART 2, paste a sample of your 
Results Grid to the Word document.*/

CREATE OR REPLACE VIEW ba710case.cumul_weekly_sales AS
	select *, round(sum(daily_sales) OVER(rows between 6 preceding and current row),2) as cumu_sales_7_days
	from ba710case.case_cumul_sales;
    
select * from ba710case.cumul_weekly_sales;

/*Calculate the weekly sales growth as a percentage change of cumulative sales
compared to the cumulative sales from the previous week (seven days ago).

When the Word document is released with PART 2, paste a sample of your 
Results Grid to the Word document.*/
/*DROP TABLE work.case_bat_sales_growth;*/

select *, round((cumulative_sales/(lag(cumulative_sales,7) over ())-1)*100,2) as pct_weekyly_increase_cumu_sales
	from ba710case.cumul_weekly_sales;

/*Question: On what date does the cumulative weekly sales growth drop below 10%?
Answer: 2016-12-06           

Question: How many days since the launch date did it take for cumulative sales growth
to drop below 10%?
Answer:     57 days                           */

select min(date(sales_transaction_date)) from ba710case.ba710_sales where product_id=7;
select datediff("2016-12-06 ","2016-10-10");

/*********************************************************************************************
Is the launch timing (October) a potential cause for the drop?
Replicate the Bat sales cumulative analysis for the Bat Limited Edition.
As above, create a cumulative sales table, compute sum of sales for the previous week,
and calculate the sales growth for the past week.*/
/*Compute a cumulative sum of sales with one row per date*/

CREATE TABLE ba710case.case_cumul_sales_bat_lim AS
select *, round((sum(daily_sales) over(order by sale_date)),2) as cumulative_sales
	from ba710case.case_daily_sales
	where model='Bat Limited Edition';
select * from ba710case.case_cumul_sales_bat_lim;


/*Compute a 7 day lag of cumulative sum of sales*/

CREATE OR REPLACE VIEW ba710case.cumul_weekly_sales_bat_lim AS
	select *, round(sum(daily_sales) OVER(rows between 6 preceding and current row),2) as cumu_sales_7_days
	from ba710case.case_cumul_sales_bat_lim;
select * from ba710case.cumul_weekly_sales_bat_lim;

    
/*Calculate a running sales growth as a percentage by comparing the
current sales to sales from 1 week prior*/

select *, round((cumulative_sales/(lag(cumulative_sales,7) over ())-1)*100,2) as pct_weekyly_increase_cumu_sales
	from ba710case.cumul_weekly_sales_bat_lim;

/*Question: On what date does the cumulative weekly sales growth drop below 10%?
Answer:  2017-04-29        

Question: How many days since the launch date did it take for cumulative sales growth
to drop below 10%?
Answer:      73 days                          
 */
select min(date(sales_transaction_date)) from ba710case.ba710_sales where product_id=8;
select datediff("2017-04-29","2017-02-15");

/*Question: Is there a difference in the behavior in cumulative sales growth 
between the Bat edition and either the Bat Limited edition or the 2013 Lemon edition?
Answer: 

The sales growth for the Bat model dropped below the 10% threshold 21.91% faster.
Without going into much detail, it seems the Bat Limited Edition model sustained higher
growth rates for a longer period of time. It seems like it may be a more successful model.  
*/                      

/*********************************************************************************************
However, the Bat Limited was at a higher price point.
Let's take a look at the 2013 Lemon model, since it's a similar price point.  
Is the launch timing (October) a potential cause for the drop?
Replicate the Bat sales cumulative analysis for the 2013 Lemon model.
As above, create a cumulative sales table, compute sum of sales for the previous week,
and calculate the sales growth for the past week.*/
/*Compute a cumulative sum of sales with one row per date*/

CREATE TABLE ba710case.case_cumul_sales_lemon_2013 AS
select *, round((sum(daily_sales) over(order by sale_date)),2) as cumulative_sales
	from ba710case.case_daily_sales
	where product_id=3;
select * from ba710case.case_cumul_sales_lemon_2013;

/*Compute a 7 day lag of cumulative sum of sales*/

CREATE OR REPLACE VIEW ba710case.cumul_weekly_sales_lemon_2013 AS
	select *, round(sum(daily_sales) OVER(rows between 6 preceding and current row),2) as cumu_sales_7_days
	from ba710case.case_cumul_sales_lemon_2013;
select * from ba710case.cumul_weekly_sales_lemon_2013;

/*Calculate a running sales growth as a percentage by comparing the
current sales to sales from 1 week prior*/

select *, round((cumulative_sales/(lag(cumulative_sales,7) over ())-1)*100,2) as pct_weekyly_increase_cumu_sales
	from ba710case.cumul_weekly_sales_lemon_2013;

/*Question: On what date does the cumulative weekly sales growth drop below 10%?
Answer:  2013-07-01    

Question: How many days since the launch date did it take for cumulative sales growth
to drop below 10%?
Answer: 61 days. 
*/                                
select min(date(sales_transaction_date)) from ba710case.ba710_sales where product_id=3;
SELECT DATEDIFF('2013-07-01 ', '2013-05-01');
/*Question: Is there a difference in the behavior in cumulative sales growth 
between the Bat edition and the 2013 Lemon edition?
Answer: 

It took almost the same number of days for the sales growth of both models to
drop below 10%. The sales growth was higher during the first week or two for the Lemon model;
but ultimately, it dropped below 10% around the time as the Bat model. More in depth analysis 
is required to make further (accurate) assumptions.                  */



/***PART 2: MARKETING ANALYSIS***/


/*General Email & Sales Prep*/

/*Create a table called WORK.CASE_SALES_EMAIL that contains all of the email data
as well as both the sales_transaction_date and the product_id from sales.
Please use the WORK.CASE_SCOOT_SALES table to capture the sales information.*/

CREATE TABLE ba710case.case_sales_email AS
	select e.*,ss.product_id, ss.sales_transaction_date  
	from ba710case.ba710_emails as e
	join ba710case.case_scoot_sales as ss
	on e.customer_id=ss.customer_id;

select * from ba710case.case_sales_email;

/*Create two separate indexes for product_id and sent_date on the newly created
   WORK.CASE_SALES_EMAIL table.*/
   
 create index idx_prod on ba710case.case_sales_email(product_id);
 create index idx_email on ba710case.case_sales_email(sent_date);
 
 
/***Product email analysis****/
/*Bat emails 30 days prior to purchase
   Create a view of the previous table that:
   - contains only emails for the Bat scooter
   - contains only emails sent 30 days prior to the purchase date*/
   
CREATE OR REPLACE VIEW ba710case.case_sales_email_view AS
	select *
		from ba710case.case_sales_email
		where product_id=7 and datediff(sales_transaction_date, sent_date) between 0 and 30;
        
select * from ba710case.case_sales_email_view;
        
/* CREATE OR REPLACE VIEW ba710case.case_sales_email_view AS
	select *
		from work.case_sales_email
		where email_subject like '%Bat%' and datediff(sales_transaction_date, sent_date) between 0 and 30;
*/

/*Filter emails*/
/*There appear to be a number of general promotional emails not 
specifically related to the Bat scooter.  Create a new view from the 
view created above that removes emails that have the following text
in their subject.

Remove emails containing:
Black Friday
25% off all EVs
It's a Christmas Miracle!
A New Year, And Some New EVs*/

CREATE OR REPLACE VIEW ba710case.case_sales_email_filtered_view AS
	select *
		from ba710case.case_sales_email_view
		where email_subject in (email_subject like '%Black Friday%' or 
							    email_subject like '%25% off all EVs%' or
                                email_subject like '%It''s a Christmas Miracle!%' or
                                email_subject like '%A New Year, And Some New EVs%');

select * from ba710case.case_sales_email_filtered_view;

/*Question: How many rows are left in the relevant emails view.*/
/*Code:*/

select count(*) as relevant_emails_count 
	from ba710case.case_sales_email_filtered_view;


/*Answer:    419 records are left    */


/*Question: How many emails were opened (opened='t')?*/
/*Code:*/
    
select count(*) as opened_relevant_emails
	from ba710case.case_sales_email_filtered_view
	where opened='t';
    
/*Answer:     105 emails were opened       */


/*Question: What percentage of relevant emails (the view above) are opened?*/
/*Code:*/

select (select count(*) 
			from ba710case.case_sales_email_filtered_view
			where opened='t') 
            / 
	   (select count(*) 
			from ba710case.case_sales_email_filtered_view)
		*100 as percentage;

 
/*Answer:      25.06%      */ 


/***Purchase email analysis***/
/*Question: How many distinct customers made a purchase (CASE_SCOOT_SALES)?*/
/*Code:*/

select count(distinct(customer_id)) as count_distinct_customers
		from ba710case.case_scoot_sales
        where product_id=7;


/*Answer:    6,659 customers     */


/*Question: What is the percentage of distinct customers made a purchase after 
    receiving an email?*/
/*Code:*/

select (select count(distinct(customer_id))
			from ba710case.case_sales_email
			where product_id=7 and datediff(sales_transaction_date, sent_date) > 0) 
            / 
	   (select count(distinct(customer_id))
			from ba710case.case_sales_email)
		*100 as pct_dist_cust_pur;
        

/*Answer:    15.72%         */
               
		
/*Question: What is the percentage of distinct customers that made a purchase 
    after opening an email?*/
/*Code:*/

select (select count(distinct(customer_id))
			from ba710case.case_sales_email
			where product_id=7 and datediff(sales_transaction_date, opened_date) > 0) / 
	   (select count(distinct(customer_id))
			from ba710case.case_sales_email)
            *100 as pct_dist_cust_pur;


/*Answer:     9.93%        */

 
/*****LEMON 2013*****/
/*Complete a comparitive analysis for the Lemon 2013 scooter.  
Irrelevant/general subjects are:
25% off all EVs
Like a Bat out of Heaven
Save the Planet
An Electric Car
We cut you a deal
Black Friday. Green Cars.
Zoom 
 
/***Product email analysis****/
/*Lemon emails 30 days prior to purchase
   Create a view that:
   - contains only emails for the Lemon 2013 scooter
   - contains only emails sent 30 days prior to the purchase date*/

CREATE OR REPLACE VIEW ba710case.case_sales_email_lemon_2013_view AS
	select *
		from ba710case.case_sales_email
		where product_id=3 and datediff(sales_transaction_date, sent_date) between 0 and 30;
        
select * from ba710case.case_sales_email_lemon_2013_view;

/*Filter emails*/
/*There appear to be a number of general promotional emails not 
specifically related to the Lemon scooter.  Create a new view from the 
view created above that removes emails that have the following text
in their subject.

Remove emails containing:
25% off all EVs
Like a Bat out of Heaven
Save the Planet
An Electric Car
We cut you a deal
Black Friday. Green Cars.
Zoom */

CREATE OR REPLACE VIEW ba710case.case_sales_email_filtered_lemon_2013_view AS
	select *
		from ba710case.case_sales_email_view
		where email_subject in (email_subject like '%25% off all EVs%' or 
							    email_subject like '%Like a Bat out of Heaven%' or
                                email_subject like '%Save the Planet%' or
                                email_subject like '%An Electric Car%' or
                                email_subject like '%We cut you a deal%' or 
							    email_subject like '%Black Friday. Green Cars.%' or
                                email_subject like '%Zoom%');

select * from ba710case.case_sales_email_filtered_lemon_2013_view;


/*Question: How many rows are left in the relevant emails view.*/
/*Code:*/

select count(*) as relevant_emails_count 
	from ba710case.case_sales_email_filtered_lemon_2013_view;

/*Answer:      381 emails are left      */


/*Question: How many emails were opened (opened='t')?*/
/*Code:*/

select count(*) as opened_relevant_emails
	from ba710case.case_sales_email_filtered_lemon_2013_view
	where opened='t';

/*Answer:    117 emails        */


/*Question: What percentage of relevant emails (the view above) are opened?*/
/*Code:*/

select (select count(*) 
			from ba710case.case_sales_email_filtered_lemon_2013_view
			where opened='t') 
            / 
	   (select count(*) 
			from ba710case.case_sales_email_filtered_lemon_2013_view)
		*100 as percentage;
 
/*Answer:      30.71%       */ 


/***Purchase email analysis***/
/*Question: How many distinct customers made a purchase (CASE_SCOOT_SALES)?*/
/*Code:*/

select count(distinct(customer_id)) as count_distinct_customers
		from ba710case.case_scoot_sales
        where product_id=3;

/*Answer:     13,854        */


/*Question: What is the percentage of distinct customers made a purchase after 
    receiving an email?*/
/*Code:*/

select (select count(distinct(customer_id))
			from ba710case.case_sales_email
			where product_id=3 and datediff(sales_transaction_date, sent_date) > 0) 
            / 
	   (select count(distinct(customer_id))
			from ba710case.case_sales_email)
		*100 as pct_dist_cust_pur;


/*Answer:     27.24%        */
               
		
/*Question: What is the percentage of distinct customers that made a purchase 
    after opening an email?*/
/*Code:*/

select (select count(distinct(customer_id))
			from ba710case.case_sales_email
			where product_id=3 and datediff(sales_transaction_date, opened_date) > 0) / 
	   (select count(distinct(customer_id))
			from ba710case.case_sales_email)
            *100 as pct_dist_cust_pur;
                
/*Answer:      15.45%       */


  