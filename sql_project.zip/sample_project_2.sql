
/* SAMPLE PROJECT _ 1 _ OF _ 2 */ 
/* Oscar Cueva*/


/* Make a copy of the balance due table in your work library.*/

drop table if exists ap.m9demo_balance_due_table;
create table ap.m9demo_balance_due_table as
select * from ap.balance_due_table;

/* Create a stored procedure called work.Balance_Due_Insert that 
       inserts a record into the work.balance_due_table by passing the 
       five following parameters: 
       
			Vendor Name 
			Invoice Number
			Invoice Amount
			Payment Amount
			Credit Amount
*/

drop procedure if exists work.Balance_Due_Insert;

DELIMITER //
CREATE PROCEDURE  ap.Balance_Due_Insert (vendor_name_param varchar(50),
										   invoice_number_param varchar(50),
                                           invoice_amount_param decimal(9,2),
                                           payment_amount_param decimal(9,2),
                                           credit_amount_param decimal(9,2))
BEGIN
insert into ap.m9demo_balance_due_table (vendor_name, invoice_number, invoice_total, payment_total, 
                             credit_total)
value (vendor_name_param, invoice_number_param, invoice_amount_param, payment_amount_param, credit_amount_param);
END //
DELIMITER ;

/* Create a trigger to validate the Vendor Name. The Vendor Name passed by the end 
       user should always be inserted as upper case, even if it isn’t entered upper case as a parameter.  
*/
drop trigger if exists ap.Balance_Due_Insert_Upper;

create trigger ap.Balance_Due_Insert_Upper
	before insert on ap.m9demo_balance_due_table
    for each row
	set new.vendor_name=upper(new.vendor_name);


/*  Create a trigger to validate the Payment Amount. The Payment Amount should never be 
       larger than the Invoice Amount, so the code should generate an error, 
       if it encounters a payment greater than the invoice.  
       (Hint: This would be an error where the data is out of range.).  
*/

drop trigger if exists ap.Balance_Due_Insert_Validate;
 
delimiter // 
create trigger ap.Balance_Due_Insert_Validate
before insert on ap.m9demo_balance_due_table
for each row
Begin
	declare invoice_total decimal(9,2);
    declare payment_total decimal(9,2);
    
	SELECT invoice_total, payment_total
    INTO invoice_total, payment_total
    FROM ap.m9demo_balance_due_table 
    where invoice_number=new.invoice_number;
	IF new.payment_total>new.invoice_total then 
		signal sqlstate "HY000"
        set message_text = "Data is out of range";
	END IF; 
end// 
delimiter ; 

Call ap.balance_due_insert("ULTIMATE BACKYARD", 1102125, 600, 50, 50);
Call ap.balance_due_insert ("ORION Ltd", 28682021, 9260.99, 0, 1000);
Call ap.balance_due_insert ("Bat Scooters", 312710, 11100, 42910, 3800);

select * from ap.m9demo_balance_due_table;



